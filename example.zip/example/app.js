/**
 * Created by alex.depatie on 6/29/15.
 */
'use strict';

angular.module('frameworkTest', ['mvFramework']);
